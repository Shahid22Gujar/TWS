import csv
#Writing file to csv
def write():
    f=open("details.csv","w",newline='')
    wo=csv.writer(f,delimiter='\t')
    wo.writerow(["title","description","amount"])
    while True:
        ti=input("Enter title:")
        desc=input("Enter description:")
        amt=input("Enter amount")
        data=[ti,desc,amt]
        wo.writerow(data)
        ch=input("Do you want to enter more:(Y/y)")
        if ch in 'Nn':
            break
    f.close()
#Reading file's data from csv
def read():
    f=open("details.csv","r")
    ro=csv.reader(f,delimiter='\t')
    # next(ro)
    for i in ro:
        if 'amount' not in i:
            i[2]=f'${i[2]}.00'
        print(i[0],i[1],i[2])
    f.close()
# write()
read()

